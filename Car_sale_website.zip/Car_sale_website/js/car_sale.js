let mobileMenu = document.querySelector('.phone_bars_menu')
document.querySelector('#bar').onclick = () => {
    mobileMenu.classList.toggle('active')
}